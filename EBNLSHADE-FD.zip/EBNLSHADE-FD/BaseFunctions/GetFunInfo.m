% ��ȡ���Ժ�����Ϣ
function [Lb, Ub, Functions, LegalDim, Optimum] = GetFunInfo(FunType,FunNum)
    global initial_flag
    initial_flag = 0;
    
    Functions = @CalculateFitness;
    
    switch FunType
        case 'CEC2008L'
            [Lb, Ub, LegalDim, Optimum] = CEC2008LFunInfo(FunNum);
        case 'CEC2005'
            [Lb, Ub, LegalDim, Optimum] = CEC2005FunInfo(FunNum);
        case 'CEC2010L'
            [Lb, Ub, LegalDim, Optimum] = CEC2010LFunInfo(FunNum);
        case 'CEC2011'
            [Lb, Ub, LegalDim, Optimum] = CEC2011get_fun_info(FunNum);
        case 'CEC2013R'
            [Lb, Ub, LegalDim, Optimum] = CEC2013RFunInfo(FunNum);
        case 'CEC2013L'
            [Lb, Ub, LegalDim, Optimum] = CEC2013LFunInfo(FunNum);
        case 'CEC2014'
            [Lb, Ub, LegalDim, Optimum] = CEC2014FunInfo(FunNum);
        case 'CEC2015'
            [Lb, Ub, LegalDim, Optimum] = CEC2015FunInfo(FunNum);
        case 'CEC2017'
            [Lb, Ub, LegalDim, Optimum] = CEC2017FunInfo(FunNum);
        case 'CEC2019'
            [Lb, Ub, LegalDim, Optimum] = CEC2019FunInfo(FunNum);
        case 'CEC2020'
            [Lb, Ub, LegalDim, Optimum] = CEC2020FunInfo(FunNum);
        case 'CEC2021'
            [Lb, Ub, LegalDim, Optimum] = CEC2021FunInfo(FunNum);
         case 'CEC2022'
            [Lb, Ub, LegalDim, Optimum] = CEC2022FunInfo(FunNum);
        case 'BenFunctions'
            [Lb, Ub, LegalDim, Optimum] = BenFunctionsInfo(FunNum);
        case 'FixedDimension'
            [Lb, Ub, LegalDim, Optimum] = FixedDimensionInfo(FunNum);
        case 'EngineeringProblem'
            [Lb, Ub, LegalDim, Optimum] = EngineeringInfo(FunNum);
        case 'Clustering'
            [Lb, Ub, LegalDim, Optimum] = ClusteringInfo(FunNum);
        otherwise
            error(['GetFunInfo �޺������� FunType = ',FunType]);
    end
end
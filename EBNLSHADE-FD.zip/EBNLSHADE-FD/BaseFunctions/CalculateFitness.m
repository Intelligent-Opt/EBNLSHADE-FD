% Calculate fitness values
function Result = CalculateFitness(FunType,FunNum,X)
    if strcmp(FunType,'CEC2010L')
        Result = benchmark_func2010(X,FunNum);
    elseif strcmp(FunType,'CEC2005')
        Result = cec05_func(X,FunNum);   
    elseif strcmp(FunType,'CEC2008L')
        Result = benchmark_func2008(X,FunNum);
     elseif strcmp(FunType,'CEC2011')
        Result = CEC2011func(X,FunNum);
        
    elseif strcmp(FunType,'CEC2013R')
        Result = cec13_func(X',FunNum)';
    
    elseif strcmp(FunType,'CEC2013L')
        Result = benchmark_func2013(X',FunNum)';
        
    elseif strcmp(FunType,'CEC2014')
        Result = cec14_func(X',FunNum)';
        
    elseif strcmp(FunType,'CEC2015')
        Result = cec15_func(X',FunNum)';
    
    elseif strcmp(FunType,'CEC2017')
        Result = cec17_func(X',FunNum)';
        
    elseif strcmp(FunType,'CEC2019')
        Result = cec19_func(X',FunNum)';
        
    elseif strcmp(FunType,'CEC2020')
        Result = cec20_func(X',FunNum)';
        
    elseif strcmp(FunType,'CEC2021')
        Result = cec21_func(X',FunNum)';
        
     elseif strcmp(FunType,'CEC2022')
        Result = cec22_func(X',FunNum)';   
        
    elseif strcmp(FunType,'BenFunctions')
        Result = BenFunctions(X,FunNum);
        
    elseif strcmp(FunType,'FixedDimension')
        Result = FixedDimension(X,FunNum);
        
    elseif strcmp(FunType,'EngineeringProblem')
        Result = EngineeringProblem(X,FunNum);
        
    elseif strcmp(FunType,'Clustering')
        Result = ClusteringProblem(X,FunNum);
        
    else
       error('CalculateFitness ==> No such funtions...'); 
    end
%     Result = Result';
end
% CEC2013 Real param test fuctions Range
function [Lb, Ub, LegalDim, Optimum] = CEC2017FunInfo(FunNum)
    TotalFunNum = 30;
    Optimum = NaN(TotalFunNum,1);
    for i = 1:TotalFunNum
        Optimum(i) = i * 100;
    end
    if FunNum > 0 && FunNum <= TotalFunNum
        Lb = -100;
        Ub = 100;
    else
        error(['CEC2017FunInfo ==> �޺��� FunNum = ',num2str(FunNum)]);
    end
    LegalDim = [10, 30, 50, 100];
end
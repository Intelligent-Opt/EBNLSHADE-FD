% Calculate fitness values
function Result = CEC2017Fun(FunType,FunNum,X)
    if strcmp(FunType,'CEC2017')
%         addpath([FunType,'/input_data/']);
        Result = cec17_func(X',FunNum);
    else
       error('CEC2017Fun ==> No such funtions...'); 
    end
end
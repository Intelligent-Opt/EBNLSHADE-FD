% CEC2013 Real param test fuctions Range
function [Lb, Ub, LegalDim, Optimum] = CEC2013RFunInfo(FunNum)
    TotalFunNum = 28;
    Optimum = NaN(TotalFunNum,1);
    for i = 1:TotalFunNum
        if i <= 14
            Optimum(i) = -(14 - FunNum + 1)*100;
        else
            Optimum(i) = (FunNum - 14)*100;
        end
    end
    
    if FunNum > 0 && FunNum <= TotalFunNum
        Lb = -100;
        Ub = 100;
    else
        error(['CEC2013FunInfo ==> �޺��� FunNum = ',num2str(FunNum)]);
    end
%     LegalDim = [10, 30, 50];
      LegalDim = [10, 30, 50,100];
end
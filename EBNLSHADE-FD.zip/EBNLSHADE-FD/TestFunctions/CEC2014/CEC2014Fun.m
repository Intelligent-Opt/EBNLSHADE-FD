% Calculate fitness values
function Result = CEC2014Fun(FunType,FunNum,X)
    if strcmp(FunType,'CEC2014')
%         addpath([FunType,'/input_data/']);
        Result = cec14_func(X',FunNum)';
    else
       error('CEC2014Fun ==> No such funtions...'); 
    end
end
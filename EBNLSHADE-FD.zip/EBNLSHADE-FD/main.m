% souce code for EBNLSHADE-FD, edited by Yinxia Wu and Yongjun Sun
clc;
clear
FunType='CEC2014'; 
Dim=30;
MaxFEs=10000*Dim;
MaxIter=4500; %May vary depending on population size or population reduction method
SwarmSize=18*Dim;
RunTimes=3;
FunId=22;
Best_X=zeros(RunTimes,Dim); % Record the best solution
Best_F=NaN(1,RunTimes);
ErrorValue=NaN(1,RunTimes); 
ConvergenceCurve=NaN(MaxIter,RunTimes);
for Run=1:RunTimes
    display(['RumNum= ',num2str(Run)]);
    display(['FuntionNum= ',num2str(FunId)]);
   [Lb, Ub, Functions, LegalDim, Optimum] = GetFunInfo(FunType,FunId);
   [BestX, BestF, HisBestF] = EBNLSHADE_FD(FunType, FunId, MaxFEs, MaxIter, SwarmSize, Lb, Ub,Dim,Functions,Run,RunTimes);
   Best_X(Run,:)=BestX;
   ErrorValue(Run)=BestF-Optimum(FunId);
   ConvergenceCurve(:,Run)=HisBestF-Optimum(FunId);
end
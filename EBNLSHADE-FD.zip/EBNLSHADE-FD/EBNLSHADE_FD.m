% edited by Xinya Wu and Yongjun Sun
% FunType: Function type, such as CEC2017,CEC2014
%FunId: Function number
%MaxFEs: Maximum fitness evalutions
%MaxIter: Maximum number of iteration
%SwarmSize: Population size
% Lb, Ub :Lower bound and upper bound of variable
%Functions: Functions used to calculate fitness
%Dim : Dimension of a function
% BestX: the solution correspond to the best fitness
% BestF: Best fitness
%HisBestF: Record the optimal fitness of each iteration

function [BestX, BestF, HisBestF] = EBNLSHADE_FD(FunType, FunId, MaxFEs, MaxIter, SwarmSize, Lb, Ub,Dim,Functions,Run,RunTimes)
      
            POP = NaN(MaxIter,1);
            F = zeros(MaxIter, 1);
            CR = zeros(MaxIter, 1);
            count = 0;
            count1 = 0;
            
            rand('seed', sum(100 * clock));
            if length(Lb) == 1
                XRange = [Lb * ones(1, Dim); Ub * ones(1, Dim)];
            else
                XRange = [Lb ; Ub];
            end
            HisBestDiversity = [];                   
            archive=[];
           %%  parameter settings for L-SHADE
            p_best_rate = 0.11;    
            EDE_best_rate = 0.10;    
            arc_rate = 1.4; 
            memory_size = 5; 
            L_Rate= 0.80;

            max_pop_size = SwarmSize;
            min_pop_size = 4.0;

            archive.NP = arc_rate * SwarmSize; % the maximum size of the archive
            archive.pop = zeros(0, Dim); % the solutions stored in te archive
            archive.funvalues = zeros(0, 1); % the function value of the archived solutions

            memory_sf = 0.5 .* ones(memory_size, 1);
            memory_cr = 0.5 .* ones(memory_size, 1);
            memory_pos = 1;
            memory_pos_1 = 1;            
            %% Initialize the main population
            PositionsOld = repmat(XRange(1, :), SwarmSize, 1) + rand(SwarmSize, Dim) .* (repmat(XRange(2, :) - XRange(1, :), SwarmSize, 1));
            Positions = PositionsOld; % the old population becomes the current population
            
            fitness = Functions(FunType,FunId,Positions);           
            t = 0;
            BestF = 1e+30;
            BestX = zeros(1, Dim);
            HisBestF = NaN(MaxIter, 1);
            %%%%%%%%%%%%%%%%%%%%%%%% for out
            for i = 1 : SwarmSize
              t = t + 1;
              if fitness(i) < BestF
                BestF = fitness(i);
                BestX = Positions(i, :);
              end
        %%  
              if t > MaxFEs; break; 
              end
            end  
            best_front_F = BestF;% Used to record the optimal solution of each iteration
            BestF_old = BestF; % Used to record the optimal solution before each initialization
            % Calculate the diversity of the initial population
           % mean_x = mean(PositionsOld);
            for j = 1:size(PositionsOld,1)
                distance(j) = norm((PositionsOld(j,:) - BestX),inf);
            end
            mean_dis_init = mean(distance);
            mean_dis_front = mean_dis_init;
            
           %%  parameter settings for Hybridization
            First_calss_percentage=0.5;
            memory_1st_class_percentage = First_calss_percentage.* ones(memory_size, 1); % Class#1 probability for Hybridization
            Hybridization_flag = 1; % Indicator flag if we need to Activate Hybridization
            Iter = 0;
            %% main loop
   while t < MaxFEs
                Iter = Iter + 1;
                Positions = PositionsOld; % the old population becomes the current population
                [~, sorted_index] = sort(fitness, 'ascend');

                mem_rand_index = ceil(memory_size * rand(SwarmSize, 1));
                mu_sf = memory_sf(mem_rand_index);
                mu_cr = memory_cr(mem_rand_index);
                mem_rand_ratio = rand(SwarmSize, 1);                
               %% for generating Hybridization Class probability
                Class_Select_Index = (memory_1st_class_percentage(mem_rand_index)>=mem_rand_ratio);
                if(Hybridization_flag == 0)
                    Class_Select_Index=or(Class_Select_Index,~Class_Select_Index);%All will be in class#1
                end
                %% for generating crossover rate
                cr = normrnd(mu_cr, 0.1);
                term_pos = find(mu_cr == -1);
                cr(term_pos) = 0;
                cr = min(cr, 1);
                cr = max(cr, 0);                
               %% for generating scaling factor
                sf = mu_sf + 0.1 * tan(pi * (rand(SwarmSize, 1) - 0.5));
                pos = find(sf <= 0);
                
                while ~ isempty(pos)
                    sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
                    pos = find(sf <= 0);
                end
                
                sf = min(sf, 1);
                r0 = [1 : SwarmSize];
                popAll = [Positions; archive.pop];
                [r1, r2] = gnR1R2(SwarmSize, size(popAll, 1), r0);
                
                pNP = max(round(p_best_rate * SwarmSize), 2); %% choose at least two best solutions
                randindex = ceil(rand(1, SwarmSize) .* pNP); %% select from [1, 2, 3, ..., pNP]
                randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
                pbest = Positions(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions

                % Here we select top EDE_best_rate% (10%) to be inculded in EDE 
                EDEpNP = max(round(EDE_best_rate * SwarmSize), 2); %% choose at least two best solutions
                EDErandindex = ceil(rand(1, SwarmSize) .* EDEpNP); %% select from [1, 2, 3, ..., pNP]
                EDErandindex = max(1, EDErandindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
                EDEpestind=sorted_index(EDErandindex);

                R = Gen_R(SwarmSize,2);
                R(:,1)=[];
                R = [R EDEpestind];
                fr=fitness(R);
                [~,I] = sort(fr,2);
                R_S=[];
                for i=1:SwarmSize
                    R_S(i,:)=R(i,I(i,:));
                end
                rb=R_S(:,1);
                rm=R_S(:,2);
                rw=R_S(:,3);
                
%                 vi = pop + sf(:, ones(1, problem_size)) .* (pop(rb, :) - pop + pop(rm, :) - pop(rw, :));
                 vi=[];

                if(sum(Class_Select_Index)~=0)
                    vi(Class_Select_Index,:) = Positions(Class_Select_Index,:) + ...
                        sf(Class_Select_Index, ones(1, Dim)) .* (pbest(Class_Select_Index,:)...
                        - Positions(Class_Select_Index,:) + Positions(r1(Class_Select_Index), :) ...
                        - popAll(r2(Class_Select_Index), :));
                end
                
                if(sum(~Class_Select_Index)~=0)
                    Sel=~Class_Select_Index;
                    vi(Sel,:) = Positions(Sel,:) + sf(Sel, ones(1, Dim))...
                        .* (Positions(rb(Sel), :) - Positions(Sel,:) + Positions(rm(Sel), :)...
                        - popAll(rw(Sel), :));
                end
                                
                vi = boundConstraint(vi, Positions, XRange);
                mask = rand(SwarmSize, Dim) > cr(:, ones(1, Dim)); % mask is used to indicate which elements of ui comes from the parent
                rows = (1 : SwarmSize)'; cols = floor(rand(SwarmSize, 1) * Dim)+1; % choose one position where the element of ui doesn't come from the parent
                jrand = sub2ind([SwarmSize Dim], rows, cols); mask(jrand) = false;
                ui = vi; ui(mask) = Positions(mask);
%                 inde=size(ui,1);
%                children_fitness=ones(inde,1)*1e10;
%                 parfor m=1:inde
%                     children_fitness(m) = Functions(FunType,FunId,ui(m,:));
%                 end
                children_fitness = Functions(FunType,FunId,ui);
%               children_fitness=children_fitness';
%%  for out               
                for i = 1 : SwarmSize
                    t = t + 1;
                    if children_fitness(i) < BestF
                        BestF = children_fitness(i);
                        BestX = ui(i, :);
                    end
                    if t > MaxFEs; break; end
                end
                
                dif = abs(fitness - children_fitness);
               %% I == 1: the parent is better; I == 2: the offspring is better
                I = (fitness > children_fitness);
                goodCR = cr(I == 1);
                goodF = sf(I == 1);
                dif_val = dif(I == 1);
                dif_val_Class_1 = dif(and(I,Class_Select_Index) == 1);
                dif_val_Class_2 = dif(and(I,~Class_Select_Index) == 1);

                if t < MaxFEs / 5
                    dis_val = sqrt(sum((ui(I==1,:) - Positions(I==1,:)).^2,2));
                end 
                
                archive = updateArchive(archive, PositionsOld(I == 1, :), fitness(I == 1));

                [fitness, I] = min([fitness, children_fitness], [], 2);
                
                PositionsOld = Positions;
                PositionsOld(I == 2, :) = ui(I == 2, :);
                
                num_success_params = numel(goodCR);
                
                 % Population diversity after iteration
                distance = [];
                for j = 1:size(PositionsOld,1)
                    distance(j) = norm((PositionsOld(j,:) - BestX),inf);
                end       
                mean_dis = mean(distance);           
                if mean_dis < mean_dis_front
                    count1 = count1+1;
                else
                    count1 = 0;
                end
                mean_dis_front = mean_dis;
                RD = mean_dis / mean_dis_init;
                RFES = t / MaxFEs;
                
             if num_success_params > 0
                if (Hybridization_flag==1)% if the Hybridization is activated
                    memory_1st_class_percentage(memory_pos_1) = memory_1st_class_percentage(memory_pos_1)*L_Rate+ (1-L_Rate)*(sum(dif_val_Class_1) / (sum(dif_val_Class_1) + sum(dif_val_Class_2)));
                    memory_1st_class_percentage(memory_pos_1)=min(memory_1st_class_percentage(memory_pos_1),0.8);
                    memory_1st_class_percentage(memory_pos_1)=max(memory_1st_class_percentage(memory_pos_1),0.2);
                end
                memory_pos_1 = memory_pos_1 + 1;
                if memory_pos_1 > memory_size;  memory_pos_1 = 1; end
             end
             if t < MaxFEs / 5
                 % Parameters are updated based on population diversity
                  if num_success_params > 0 
                    sum_dis = sum(dis_val);
                    dis_val = dis_val / sum_dis;

                    %% for updating the memory of scaling factor 
                    memory_sf(memory_pos) = (dis_val' * (goodF .^ 2)) / (dis_val' * goodF);

                    %% for updating the memory of crossover rate
                    if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
                        memory_cr(memory_pos)  = -1;
                    else
                        memory_cr(memory_pos) = (dis_val' * (goodCR .^ 2)) / (dis_val' * goodCR);
                    end                               
                    memory_pos = memory_pos + 1;
                    if memory_pos > memory_size;  memory_pos = 1; end
                  end                    
             else
                if num_success_params > 0
                    sum_dif = sum(dif_val);
                    dif_val = dif_val / sum_dif;                   
                   %% for updating the memory of scaling factor
                    memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);
                    
                    %% for updating the memory of crossover rate
                    if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
                        memory_cr(memory_pos)  = -1;
                    else
                        memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
                    end
                    memory_pos = memory_pos + 1;
                    if memory_pos > memory_size;  memory_pos = 1; end
                end
             end
                
       %% for resizing the population size
        if t <= MaxFEs / 5
            % Population reduction according to population diversity
            if RD > exp(-(RFES-0.1)) % Delete the individuals
                num = 1;
                plan_pop_size = SwarmSize - num;                     
            elseif RD <exp(-(RFES+0.1))% Add individuals
                num = 1;                                  
                if SwarmSize + num <= max_pop_size
                    plan_pop_size = SwarmSize + num;  
                else
                    plan_pop_size = SwarmSize;
                end                
            else
                plan_pop_size = SwarmSize;
            end       
        else
            if BestF < best_front_F 
                count = 0;
                plan_pop_size =  SwarmSize ;
            else
                count = count + 1;
                if Dim == 30
                   W = 0.13;
                elseif Dim == 50
                   W = 0.15;
                else
                    W=0.15;
                end
                Fs = sawtooth(W*Iter); 
                M = 1 - 1 / (1 + exp(10 - ((15 * t) / MaxFEs)));    
                Fl = (max_pop_size-min_pop_size) * M + min_pop_size;
                a = 0.95;
                plan_pop_size = round(a*Fl+(1-a)*Fl*Fs);  

            end 
        end
        % To reduce the population
        if SwarmSize > plan_pop_size
            reduction_ind_num = SwarmSize - plan_pop_size;
            if SwarmSize - reduction_ind_num <  min_pop_size; reduction_ind_num = SwarmSize - min_pop_size;end
            SwarmSize = SwarmSize - reduction_ind_num;
            for r = 1 : reduction_ind_num
                [~, indBest] = sort(fitness, 'ascend');
                worst_ind = indBest(end);
                PositionsOld(worst_ind,:) = [];
                Positions(worst_ind,:) = [];
                fitness(worst_ind,:) = [];
            end
            archive.NP = round(arc_rate * SwarmSize);
            if size(archive.pop, 1) > archive.NP
                rndpos = randperm(size(archive.pop, 1));
                rndpos = rndpos(1 : archive.NP);
                archive.pop = archive.pop(rndpos, :);
                archive.funvalues = archive.funvalues(rndpos);
            end
        else
            % Add the corresponding individuals
               increase_ind_num = plan_pop_size - SwarmSize;   
               if size(archive.pop, 1) >= increase_ind_num
                   temp_index = randperm(size(archive.pop, 1),increase_ind_num);
                   PositionsOld = [PositionsOld;archive.pop(temp_index,:)];
                   fitness = [fitness;archive.funvalues(temp_index)];
                   SwarmSize = SwarmSize + increase_ind_num;                   
               else                  
                   temp_index = randperm(size(archive.pop, 1),size(archive.pop, 1));
                   PositionsOld = [PositionsOld;archive.pop(temp_index,:)];
                   fitness = [fitness;archive.funvalues(temp_index)];
                   SwarmSize = SwarmSize + size(archive.pop, 1);                   
              end
               archive.NP = round(arc_rate * SwarmSize);               
        end
        best_front_F = BestF;
        % If diversity has been decreasing for 20 consecutive generations, add an individual to the current population
        if count1 >= 20  || count >= 20
               count1 = 0;
               count = 0;
               % Add corresponding individuals to the current population from external archives                
               increase_ind_num = 1;   
               if size(archive.pop, 1) >= increase_ind_num
                   temp_index = randperm(size(archive.pop, 1),increase_ind_num);
                   PositionsOld = [PositionsOld;archive.pop(temp_index,:)];
                   fitness = [fitness;archive.funvalues(temp_index)];
                   SwarmSize = SwarmSize + increase_ind_num;                   
               else    
                   temp_index = randperm(size(archive.pop, 1),size(archive.pop, 1));
                   PositionsOld = [PositionsOld;archive.pop(temp_index,:)];
                   fitness = [fitness;archive.funvalues(temp_index)];
                   SwarmSize = SwarmSize + size(archive.pop, 1);                   
              end
               archive.NP = round(arc_rate * SwarmSize);                                  
        end
       if Iter < MaxIter
                HisBestF(Iter) = min(BestF,BestF_old);
                if Run == RunTimes                      
                    POP(Iter) = SwarmSize;
                    F(Iter) = sf(1);
                    CR(Iter) = cr(1);
                end
         else
                HisBestF(MaxIter) = min(BestF,BestF_old);
                if Run == RunTimes                      
                    POP(MaxIter) = SwarmSize;
                    F(MaxIter) = sf(1);
                    CR(MaxIter) = cr(1);
                end
        end
   end

end                
function vi = boundConstraint (vi, pop, lu)

% if the boundary constraint is violated, set the value to be the middle
% of the previous value and the bound
[NP, D] = size(pop);  % the population size and the problem's dimension

%% check the lower bound
xl = repmat(lu(1, :), NP, 1);
pos = vi < xl;
vi(pos) = (pop(pos) + xl(pos)) / 2;

%% check the upper bound
xu = repmat(lu(2, :), NP, 1);
pos = vi > xu;
vi(pos) = (pop(pos) + xu(pos)) / 2;
end
%%
function [r1, r2] = gnR1R2(NP1, NP2, r0)

% gnA1A2 generate two column vectors r1 and r2 of size NP1 & NP2, respectively
%    r1's elements are choosen from {1, 2, ..., NP1} & r1(i) ~= r0(i)
%    r2's elements are choosen from {1, 2, ..., NP2} & r2(i) ~= r1(i) & r2(i) ~= r0(i)
%
% Call:
%    [r1 r2 ...] = gnA1A2(NP1)   % r0 is set to be (1:NP1)'
%    [r1 r2 ...] = gnA1A2(NP1, r0) % r0 should be of length NP1
%
NP0 = length(r0);

r1 = floor(rand(1, NP0) * NP1) + 1;
%for i = 1 : inf
for i = 1 : 99999999
    pos = (r1 == r0);
    if sum(pos) == 0
        break;
    else % regenerate r1 if it is equal to r0
        r1(pos) = floor(rand(1, sum(pos)) * NP1) + 1;
    end
    if i > 1000 % this has never happened so far
        error('Can not genrate r1 in 1000 iterations');
    end
end

r2 = floor(rand(1, NP0) * NP2) + 1;
%for i = 1 : inf
for i = 1 : 99999999
    pos = ((r2 == r1) | (r2 == r0));
    if sum(pos)==0
        break;
    else % regenerate r2 if it is equal to r0 or r1
        r2(pos) = floor(rand(1, sum(pos)) * NP2) + 1;
    end
    if i > 1000 % this has never happened so far
        error('Can not genrate r2 in 1000 iterations');
    end
end
end
%% 
function R = Gen_R(NP_Size,N)

% Gen_R generate N column vectors r1, r2, ..., rN of size NP_Size
%    R's elements are choosen from {1, 2, ..., NP_Size} & R(j,i) are unique per row

% Call:
%    [R] = Gen_R(NP_Size)   % N is set to be 1;
%    [R] = Gen_R(NP_Size,N) 
R(1,:)=1:NP_Size;

for i=2:N+1
    
    R(i,:) = ceil(rand(NP_Size,1) * NP_Size);
    
    flag=0;
    while flag ~= 1
        pos = (R(i,:) == R(1,:));
        for w=2:i-1
            pos=or(pos,(R(i,:) == R(w,:)));
        end
        if sum(pos) == 0
            flag=1;
        else
            R(i,pos)= floor(rand(sum(pos),1 ) * NP_Size) + 1;
        end
    end
end

R=R';

end
%%
function archive = updateArchive(archive, pop, funvalue)
% Update the archive with input solutions
%   Step 1: Add new solution to the archive
%   Step 2: Remove duplicate elements
%   Step 3: If necessary, randomly remove some solutions to maintain the archive size
if archive.NP == 0, return; end

if size(pop, 1) ~= size(funvalue,1), error('check it'); end

% Method 2: Remove duplicate elements
popAll = [archive.pop; pop ];
funvalues = [archive.funvalues; funvalue ];
[~, IX]= unique(popAll, 'rows');
if length(IX) < size(popAll, 1) % There exist some duplicate solutions
  popAll = popAll(IX, :);
  funvalues = funvalues(IX, :);
end

if size(popAll, 1) <= archive.NP   % add all new individuals
  archive.pop = popAll;
  archive.funvalues = funvalues;
else                % randomly remove some solutions
  rndpos = randperm(size(popAll, 1)); % equivelent to "randperm";
  rndpos = rndpos(1 : archive.NP);
  
  archive.pop = popAll  (rndpos, :);
  archive.funvalues = funvalues(rndpos, :);
end
end